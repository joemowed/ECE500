1.  Extract all 
2.  Run the "homework1_unity.exe" executable from the "builds" folder	